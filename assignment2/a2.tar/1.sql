prompt Question 1 - me7
select distinct vehicle_id  
from owner, people
where (owner.owner_id = people.sin and people.addr NOT LIKE 'Edmonton');

